﻿---- Insert 15 rows of sample data with Email and Password columns
--INSERT INTO Customers (IC_Passport, Name, Address, PhoneNumber, DOB, Email, Password) VALUES
--('A000001', 'John Doe', '123 Elm St, Springfield',1234567890, '1985-05-15', 'john.doe@example.com', 'password123'),
--('A000002', 'Jane Smith', '456 Oak St, Springfield', 2345678901, '1990-08-22', 'jane.smith@example.com', 'password456'),
--('A000003', 'Alice Johnson', '789 Pine St, Springfield', 3456789012, '1978-12-01', 'alice.johnson@example.com', 'password789'),
--('A000004', 'Bob Brown', '321 Maple St, Springfield', 4567890123, '1992-07-11', 'bob.brown@example.com', 'password012'),
--('A000005', 'Charlie Davis', '654 Birch St, Springfield', 5678901234, '1983-11-30', 'charlie.davis@example.com', 'password345'),
--('A000006', 'Diana Green', '987 Cedar St, Springfield', 6789012345, '1987-04-23', 'diana.green@example.com', 'password678'),
--('A000007', 'Edward Harris', '135 Walnut St, Springfield', 7890123456, '1995-09-05', 'edward.harris@example.com', 'password901'),
--('A000008', 'Fiona Clark', '246 Chestnut St, Springfield', 8901234567, '1980-02-14', 'fiona.clark@example.com', 'password234'),
--('A000009', 'George Lewis', '357 Fir St, Springfield', 9012345678, '1989-10-19', 'george.lewis@example.com', 'password567'),
--('A000010', 'Hannah Walker', '468 Spruce St, Springfield', 1234567891, '1993-01-08', 'hannah.walker@example.com', 'password890'),
--('A000011', 'Isaac Hall', '579 Ash St, Springfield', 2345678902, '1986-03-17', 'isaac.hall@example.com', 'password1234'),
--('A000012', 'Jasmine Young', '680 Maple St, Springfield', 3456789013, '1991-06-25', 'jasmine.young@example.com', 'password5678'),
--('A000013', 'Kevin King', '791 Oak St, Springfield', 4567890124, '1982-12-29', 'kevin.king@example.com', 'password9012'),
--('A000014', 'Laura Adams', '902 Pine St, Springfield', 5678901235, '1994-07-14', 'laura.adams@example.com', 'password3456'),
--('A000015', 'Michael Scott', '213 Elm St, Springfield', 6789012346, '1988-09-30', 'michael.scott@example.com', 'password7890');
-- Insert 10 rows of data into Housekeepers table

--INSERT INTO Housekeepers (HousekeeperID, Name, Username, Password) VALUES
--(1, 'Alice Johnson', 'alice.johnson', 'password123');

SELECT *
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME = 'Housee';


