﻿namespace IOOP_Group_Assignment
{
    partial class AddCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Full_NameTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AddCustomr_Btn = new System.Windows.Forms.Button();
            this.IC_TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PhnNoTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Address_TextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Email_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Pass_TextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // Full_NameTextBox
            // 
            this.Full_NameTextBox.Location = new System.Drawing.Point(402, 40);
            this.Full_NameTextBox.Name = "Full_NameTextBox";
            this.Full_NameTextBox.Size = new System.Drawing.Size(166, 20);
            this.Full_NameTextBox.TabIndex = 81;
            this.Full_NameTextBox.TextChanged += new System.EventHandler(this.Full_NameTextBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(240, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 20);
            this.label3.TabIndex = 80;
            this.label3.Text = "Full Name:";
            // 
            // AddCustomr_Btn
            // 
            this.AddCustomr_Btn.AutoSize = true;
            this.AddCustomr_Btn.BackColor = System.Drawing.Color.DodgerBlue;
            this.AddCustomr_Btn.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.AddCustomr_Btn.FlatAppearance.BorderSize = 0;
            this.AddCustomr_Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue;
            this.AddCustomr_Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.AddCustomr_Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddCustomr_Btn.Font = new System.Drawing.Font("Calibri", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddCustomr_Btn.ForeColor = System.Drawing.Color.White;
            this.AddCustomr_Btn.Location = new System.Drawing.Point(285, 378);
            this.AddCustomr_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.AddCustomr_Btn.Name = "AddCustomr_Btn";
            this.AddCustomr_Btn.Size = new System.Drawing.Size(229, 32);
            this.AddCustomr_Btn.TabIndex = 79;
            this.AddCustomr_Btn.Text = "Add Customer";
            this.AddCustomr_Btn.UseVisualStyleBackColor = false;
            this.AddCustomr_Btn.Click += new System.EventHandler(this.AddCustomr_Btn_Click);
            // 
            // IC_TextBox
            // 
            this.IC_TextBox.Location = new System.Drawing.Point(406, 84);
            this.IC_TextBox.Name = "IC_TextBox";
            this.IC_TextBox.Size = new System.Drawing.Size(166, 20);
            this.IC_TextBox.TabIndex = 89;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(240, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 20);
            this.label5.TabIndex = 88;
            this.label5.Text = "IC Number:";
            // 
            // PhnNoTextBox
            // 
            this.PhnNoTextBox.Location = new System.Drawing.Point(406, 175);
            this.PhnNoTextBox.Name = "PhnNoTextBox";
            this.PhnNoTextBox.Size = new System.Drawing.Size(166, 20);
            this.PhnNoTextBox.TabIndex = 101;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkBlue;
            this.label10.Location = new System.Drawing.Point(240, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 20);
            this.label10.TabIndex = 100;
            this.label10.Text = "Phone Number:";
            // 
            // Address_TextBox
            // 
            this.Address_TextBox.Location = new System.Drawing.Point(402, 131);
            this.Address_TextBox.Name = "Address_TextBox";
            this.Address_TextBox.Size = new System.Drawing.Size(166, 20);
            this.Address_TextBox.TabIndex = 99;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkBlue;
            this.label11.Location = new System.Drawing.Point(240, 131);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 20);
            this.label11.TabIndex = 98;
            this.label11.Text = "Address:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(234, 215);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 102;
            this.label1.Text = "DOB:";
            // 
            // Email_TextBox
            // 
            this.Email_TextBox.Location = new System.Drawing.Point(400, 261);
            this.Email_TextBox.Name = "Email_TextBox";
            this.Email_TextBox.Size = new System.Drawing.Size(166, 20);
            this.Email_TextBox.TabIndex = 105;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(234, 261);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 20);
            this.label2.TabIndex = 104;
            this.label2.Text = "Email:";
            // 
            // Pass_TextBox
            // 
            this.Pass_TextBox.Location = new System.Drawing.Point(400, 302);
            this.Pass_TextBox.Name = "Pass_TextBox";
            this.Pass_TextBox.Size = new System.Drawing.Size(166, 20);
            this.Pass_TextBox.TabIndex = 107;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.Location = new System.Drawing.Point(234, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 20);
            this.label4.TabIndex = 106;
            this.label4.Text = "Password:";
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(400, 215);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(200, 20);
            this.DOB.TabIndex = 108;
            // 
            // AddCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.Pass_TextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Email_TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PhnNoTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Address_TextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.IC_TextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Full_NameTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AddCustomr_Btn);
            this.Name = "AddCustomer";
            this.Text = "AddCustomer";
            this.Load += new System.EventHandler(this.AddCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Full_NameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button AddCustomr_Btn;
        private System.Windows.Forms.TextBox IC_TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox PhnNoTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Address_TextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Email_TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Pass_TextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker DOB;
    }
}