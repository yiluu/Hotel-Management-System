﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace IOOP_Group_Assignment
{


    public partial class ChangeProfilePicturePage : Form
    {
        public ChangeProfilePicturePage()
        {
            InitializeComponent();
        }

        



        private void btn_Pfp_Click(object sender, EventArgs e)
        {

        }
    }
}
