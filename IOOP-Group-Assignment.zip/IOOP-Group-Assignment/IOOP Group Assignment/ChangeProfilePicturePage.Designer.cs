﻿namespace IOOP_Group_Assignment
{
    partial class ChangeProfilePicturePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Pfp2 = new System.Windows.Forms.Button();
            this.btn_Pfp3 = new System.Windows.Forms.Button();
            this.btn_Pfp4 = new System.Windows.Forms.Button();
            this.btn_Pfp5 = new System.Windows.Forms.Button();
            this.btn_Pfp6 = new System.Windows.Forms.Button();
            this.btn_Pfp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 33);
            this.label1.TabIndex = 35;
            this.label1.Text = "Choose Profile Picture";
            // 
            // btn_Pfp2
            // 
            this.btn_Pfp2.Location = new System.Drawing.Point(101, 110);
            this.btn_Pfp2.Name = "btn_Pfp2";
            this.btn_Pfp2.Size = new System.Drawing.Size(49, 46);
            this.btn_Pfp2.TabIndex = 41;
            this.btn_Pfp2.UseVisualStyleBackColor = true;
            // 
            // btn_Pfp3
            // 
            this.btn_Pfp3.Location = new System.Drawing.Point(178, 110);
            this.btn_Pfp3.Name = "btn_Pfp3";
            this.btn_Pfp3.Size = new System.Drawing.Size(49, 46);
            this.btn_Pfp3.TabIndex = 40;
            this.btn_Pfp3.UseVisualStyleBackColor = true;
            // 
            // btn_Pfp4
            // 
            this.btn_Pfp4.Location = new System.Drawing.Point(256, 110);
            this.btn_Pfp4.Name = "btn_Pfp4";
            this.btn_Pfp4.Size = new System.Drawing.Size(49, 46);
            this.btn_Pfp4.TabIndex = 39;
            this.btn_Pfp4.UseVisualStyleBackColor = true;
            // 
            // btn_Pfp5
            // 
            this.btn_Pfp5.Location = new System.Drawing.Point(333, 110);
            this.btn_Pfp5.Name = "btn_Pfp5";
            this.btn_Pfp5.Size = new System.Drawing.Size(49, 46);
            this.btn_Pfp5.TabIndex = 38;
            this.btn_Pfp5.UseVisualStyleBackColor = true;
            // 
            // btn_Pfp6
            // 
            this.btn_Pfp6.Location = new System.Drawing.Point(409, 110);
            this.btn_Pfp6.Name = "btn_Pfp6";
            this.btn_Pfp6.Size = new System.Drawing.Size(49, 46);
            this.btn_Pfp6.TabIndex = 37;
            this.btn_Pfp6.UseVisualStyleBackColor = true;
            // 
            // btn_Pfp
            // 
            this.btn_Pfp.Location = new System.Drawing.Point(24, 110);
            this.btn_Pfp.Name = "btn_Pfp";
            this.btn_Pfp.Size = new System.Drawing.Size(49, 46);
            this.btn_Pfp.TabIndex = 34;
            this.btn_Pfp.UseVisualStyleBackColor = true;
            this.btn_Pfp.Click += new System.EventHandler(this.btn_Pfp_Click);
            // 
            // ChangeProfilePicturePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(484, 281);
            this.Controls.Add(this.btn_Pfp2);
            this.Controls.Add(this.btn_Pfp3);
            this.Controls.Add(this.btn_Pfp4);
            this.Controls.Add(this.btn_Pfp5);
            this.Controls.Add(this.btn_Pfp6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Pfp);
            this.MaximizeBox = false;
            this.Name = "ChangeProfilePicturePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangeProfilePicturePage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Pfp;
        private System.Windows.Forms.Button btn_Pfp6;
        private System.Windows.Forms.Button btn_Pfp5;
        private System.Windows.Forms.Button btn_Pfp4;
        private System.Windows.Forms.Button btn_Pfp3;
        private System.Windows.Forms.Button btn_Pfp2;
    }
}