﻿namespace IOOP_Group_Assignment
{
    internal class Managereservations
    {
        public Managereservations()
        {
        }
    }
}